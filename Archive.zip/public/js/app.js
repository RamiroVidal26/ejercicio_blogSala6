/**
 * Colocar aquí JS "propio".
 * Notar que este código se ejecutará en el navegador.
 */
